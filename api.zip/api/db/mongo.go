package db

import (
	"context"
	"time"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var DB *mongo.Client

const Database string = "Stopify"

// collection names as variables to prevent accidentally creating collections from misspells
const Users string = "Users"
const Artists string = "Artists"
const Albums string = "Albums"
const Tracks string = "Tracks"

const ctxTimeSecond int = 5

func init() {
	clientOptions := options.Client().ApplyURI("mongodb://mongodb:27017")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	DB, _ = mongo.Connect(ctx, clientOptions)
}

// Col is a helper to easilly get a collection object given its name
func Col(col string) *mongo.Collection {
	return DB.Database(Database).Collection(col)
}
