package db

import (
	"api/gen"
	"context"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"strings"
	"time"
)

const idLength int = 32

// GenBytes generates a slice of length l of random bytes
func genBytes(l int) []byte {
	b := make([]byte, l)
	rand.Read(b)

	return b
}

// GenID generates random IDs of length `isLength`
// given type t
func GenID(t string) string {
	b := genBytes(idLength)
	s := base64.StdEncoding.EncodeToString(b) // string

	// shorten and lowercase c
	// TODO: check that t is one of the mongo collections
	t = strings.ToLower(t)

	return fmt.Sprintf("%s-%s", t, s)
}

func GetMongoCtx() (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.Background(), time.Duration(ctxTimeSecond)*time.Second)
}

func GetArtistByID(artistID string) (gen.Artist, error) {
	col := Col(Artists) // get from Artists collection

	ctx, cancel := GetMongoCtx()
	defer cancel()

	var artistResult gen.Artist
	err := col.FindOne(ctx, gen.Artist{ArtistID: artistID}).Decode(&artistResult)

	return artistResult, err
}

// func AssertArtist(artist *gen.ArtistInput) bool {

// 	id := artist.ArtistID

// 	// check for ID
// 	if id != nil {
// 		// search db
// 		artistResult, err := GetArtistByID(*id)

// 		if err != nil {
// 			log.Fatal(err)
// 		}

// 		fmt.Println("artistResult:", artistResult)
// 	}

// }
