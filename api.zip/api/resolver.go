package main

import (
	"api/db"
	"api/gen"
	"context"
	"errors"
	"fmt"
	"log"
)

// THIS CODE IS A STARTING POINT ONLY. IT WILL NOT BE UPDATED WITH SCHEMA CHANGES.

// Resolver struct modified to be able to access mutation and query resolvers
type Resolver struct {
	m *mutationResolver
	q *queryResolver
}

func (r *Resolver) Mutation() gen.MutationResolver {
	return &mutationResolver{r}
}
func (r *Resolver) Query() gen.QueryResolver {
	return &queryResolver{r}
}

type mutationResolver struct{ *Resolver }

func (r *mutationResolver) AddTrack(ctx context.Context, trackInput gen.TrackInput) (*gen.Track, error) {

	// trackID in trackInput should not be defined
	if trackInput.TrackID != nil {
		return &gen.Track{}, errors.New("AddTrack Error: trackID should not be defined when adding new tracks")
	}

	// check for artist field
	if trackInput.Artist == nil {
		return &gen.Track{}, errors.New("AddTrack Error: undefined artist")
	}

	// gen id
	id := db.GenID(db.Tracks)
	fmt.Println("Generated ID:", id)

	existingArtist, err := r.q.Artist(ctx, *trackInput.Artist) // query from other resolvers
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("existing artist:", existingArtist)

	artist, err := r.AddArtist(ctx, *trackInput.Artist)

	// it works when you pass it through the type first
	track := &gen.Track{
		TrackID: id,s
		Artist:  existingArtist,
		Title:   *trackInput.Title,
		Genre:   trackInput.Genre,
	}

	fmrt.Println(track)
	// check if trackID is defined.

	// check db for existing track based on trackID
	// fmt.Println("trackInput", track)
	return nil, nil
}

func (r *mutationResolver) RemTrack(ctx context.Context, trackID string) (*gen.Track, error) {

	track := &gen.Track{
		TrackID: trackID,
	}

	fmt.Println(track)

	// remove from database

	panic("not implemented")
}
func (r *mutationResolver) AddAlbum(ctx context.Context, albumInput gen.AlbumInput) (*gen.Album, error) {

	album := &gen.Album{
		AlbumID: *albumInput.AlbumID,
		// Artist:  *albumInput.ArtistID,
		Title:   albumInput.Title,
		Release: albumInput.Release,
		Genre:   albumInput.Genre,
		// Tracks:
	}

	fmt.Println(album)

	panic("not implemented")
}
func (r *mutationResolver) RemAlbum(ctx context.Context, albumID string) (*gen.Album, error) {
	album := &gen.Album{
		AlbumID: albumID,
	}

	fmt.Println(album)
	panic("not implemented")
}
func (r *mutationResolver) AddTracks(ctx context.Context, albumID string, tracksInput []*gen.TrackInput) (*gen.Album, error) {

	panic("not implemented")
}
func (r *mutationResolver) AddArtist(ctx context.Context, artistInput gen.ArtistInput) (*gen.Artist, error) {
	panic("not implemented")
}
func (r *mutationResolver) RemArtist(ctx context.Context, artistID string) (*gen.Artist, error) {
	panic("not implemented")
}
func (r *mutationResolver) AddUser(ctx context.Context, userInput gen.UserAdd) (gen.User, error) {
	panic("not implemented")
}
func (r *mutationResolver) ModUser(ctx context.Context, userID string, userInput gen.UserMod) (gen.User, error) {
	panic("not implemented")
}
func (r *mutationResolver) RemUser(ctx context.Context, userID string) (gen.User, error) {
	panic("not implemented")
}
func (r *mutationResolver) AddTrackFavorite(ctx context.Context, userID string, trackID *string) (*gen.Track, error) {
	panic("not implemented")
}
func (r *mutationResolver) RemTrackFavorite(ctx context.Context, userID string, trackID *string) (*gen.Track, error) {
	panic("not implemented")
}
func (r *mutationResolver) AddAlbumFavorite(ctx context.Context, userID string, albumID *string) (*gen.Album, error) {
	panic("not implemented")
}
func (r *mutationResolver) RemAlbumFavorite(ctx context.Context, userID string, albumID *string) (*gen.Album, error) {
	panic("not implemented")
}
func (r *mutationResolver) AddFollowArtist(ctx context.Context, userID string, artistID string) (*gen.Artist, error) {
	panic("not implemented")
}
func (r *mutationResolver) RemFollowArtist(ctx context.Context, userID string, artistID string) (*gen.Artist, error) {
	panic("not implemented")
}
func (r *mutationResolver) AddTrackHistory(ctx context.Context, userID string, trackID string) (*gen.Track, error) {
	panic("not implemented")
}
func (r *mutationResolver) RemTrackHistory(ctx context.Context, userID string, trackID string) (*gen.Track, error) {
	panic("not implemented")
}
func (r *mutationResolver) AddAlbumHistory(ctx context.Context, userID string, albumID string) (*gen.Album, error) {
	panic("not implemented")
}
func (r *mutationResolver) RemAlbumHistory(ctx context.Context, userID string, albumID string) (*gen.Album, error) {
	panic("not implemented")
}

type queryResolver struct{ *Resolver }

func (r *queryResolver) User(ctx context.Context, userInput gen.UserQuery) (gen.User, error) {
	panic("not implemented")

}
func (r *queryResolver) Artist(ctx context.Context, artistInput gen.ArtistInput) (*gen.Artist, error) {

	// check for required fields

	col, err := Col(db.Artist)

	panic("not implemented")
}
func (r *queryResolver) Album(ctx context.Context, albumInput gen.AlbumInput) (*gen.Album, error) {
	panic("not implemented")
}
func (r *queryResolver) Track(ctx context.Context, trackInput gen.TrackInput) (*gen.Track, error) {
	panic("not implemented")
}
